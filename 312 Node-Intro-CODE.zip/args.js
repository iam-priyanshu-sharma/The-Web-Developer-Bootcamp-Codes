console.log("HELLO FROM ARGS FILE!")
console.log(process.argv)