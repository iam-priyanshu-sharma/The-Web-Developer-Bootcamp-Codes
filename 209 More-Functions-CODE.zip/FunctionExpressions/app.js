// function add(x, y) {
//     return x + y;
// }

const add = function (x, y) {
    return x + y;
}


