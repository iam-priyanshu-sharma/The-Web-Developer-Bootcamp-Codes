module.exports = {
    name: 'janet',
    color: 'orange'
}